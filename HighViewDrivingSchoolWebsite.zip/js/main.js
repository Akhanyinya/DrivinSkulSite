(function ($) {
    "use strict";

    // Spinner
    var spinner = function () {
        setTimeout(function () {
            if ($('#spinner').length > 0) {
                $('#spinner').removeClass('show');
            }
        }, 1);
    };
    spinner();


    // Initiate the wowjs
    new WOW().init();


    // Sticky Navbar
    $(window).scroll(function () {
        if ($(this).scrollTop() > 300) {
            $('.sticky-top').addClass('shadow-sm').css('top', '0');
        } else {
            $('.sticky-top').removeClass('shadow-sm').css('top', '-100px');
        }
    });


    // Back to top button
    $(window).scroll(function () {
        if ($(this).scrollTop() > 300) {
            $('.back-to-top').fadeIn('slow');
        } else {
            $('.back-to-top').fadeOut('slow');
        }
    });
    $('.back-to-top').click(function () {
        $('html, body').animate({scrollTop: 0}, 1500, 'easeInOutExpo');
        return false;
    });


    // Testimonials carousel
    $(".testimonial-carousel").owlCarousel({
        autoplay: true,
        smartSpeed: 1000,
        items: 1,
        dots: true,
        loop: true 
    });

    // Function to open the dialog
function openDialog() {
    const dialog = document.getElementById("dialog");
    dialog.showModal();
  
    // Apply the blur effect to the background
    document.body.classList.add("blur");
  }
  
  // Function to close the dialog
  function closeDialog() {
    const dialog = document.getElementById("dialog");
    dialog.close();
  
    // Remove the blur effect from the background
    document.body.classList.remove("blur");
  }
  
  // Function to preview the uploaded image
  function previewImage(input) {
    const preview = document.getElementById("imagePreview");
    if (input.files && input.files[0]) {
      const reader = new FileReader();
      reader.onload = function (e) {
        preview.src = e.target.result;
        preview.style.display = "block";
      };
      reader.readAsDataURL(input.files[0]);
    }
  }
  
  // Add event listeners to the file input to trigger the previewImage function
  document.getElementById("passportPhoto").addEventListener("change", function () {
    previewImage(this);
  });
  

    })(jQuery);
